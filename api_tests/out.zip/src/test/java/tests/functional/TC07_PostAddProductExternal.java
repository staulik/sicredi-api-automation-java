package tests.functional;

import org.junit.jupiter.api.Test;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.io.IOException;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;

public class TC07_PostAddProductExternal {

    @Test
    public void deveCriarProdutoComMassaExterna() throws IOException {
        // Lê o conteúdo do arquivo produto.json
        String produtoJson = new String(Files.readAllBytes(Paths.get("src/test/java/resources/data/produto.json")));

        // Envia o POST usando a massa externa
        given()
                .header("Content-Type", "application/json")
                .body(produtoJson)
                .when()
                .post("https://dummyjson.com/products/add")
                .then()
                .statusCode(200) // API retorna 200 para criação
                .body("title", equalTo("Produto Massa Externa"))
                .log().all();
    }
}
